package edu.upf;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.SparkConf;
import edu.upf.filter.FileLanguageFilter;
//import edu.upf.uploader.SparkS3Uploader;

import java.util.Arrays;
import java.util.List;

import static edu.upf.filter.FileLanguageFilter.filterLanguage;

public class TwitterLanguageFilterApp {
    public static void main(String[] args) {
        // Verificar la cantidad correcta de argumentos
        if (args.length < 3) {
            System.err.println("Usage: TwitterLanguageFilterApp <language> <outputFile> <bucket> <inputFile1> <inputFile2> ...");
            System.exit(1);
        }

        // Argumentos de línea de comandos
        String language = args[0];
        String outputFile = args[1];
        String bucket = args[2];
        List<String> inputFiles = Arrays.asList(Arrays.copyOfRange(args, 3, args.length));

        // Configuración de Spark
        SparkConf conf = new SparkConf().setAppName("TwitterLanguageFilterApp").setMaster("local[*]");
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Procesamiento de archivos usando Spark
        JavaRDD<String> allLines = sc.parallelize(inputFiles)
                .flatMap(file -> filterLanguage(sc.textFile(file), language).toLocalIterator());

        // Guardar el resultado en un único archivo local
        allLines.coalesce(1).saveAsTextFile("file://" + outputFile);

        // Subir el resultado a S3
        //S3Uploader = new SparkS3Uploader(bucket, language);
        //uploader.upload(Arrays.asList(outputFile));

    }
}