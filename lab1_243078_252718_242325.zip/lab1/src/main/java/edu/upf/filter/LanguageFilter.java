package edu.upf.filter;

public interface LanguageFilter {

  /**
   * Process
   * @param language
   * @return
   */
  void filterLanguage(String language) throws Exception;
}
